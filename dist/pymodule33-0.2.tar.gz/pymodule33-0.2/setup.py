from setuptools import setup, find_packages

setup(
    name='pymodule33',
    version='0.2',
    packages=find_packages(),
    install_requires=[],
    author='David',
    author_email='ddickson@gleason.com',
    description='A simple Python package',
)
